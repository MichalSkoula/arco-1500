## Game of Life

©2018 David Donátek
